/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author ADMIN
 */
public class XDate {
    private static final ThreadLocal<SimpleDateFormat> formater = ThreadLocal.withInitial(() -> new SimpleDateFormat());
    private static final Lock lock = new ReentrantLock();

    public static Date toDate(String date, String pattern) {
        try {
            formater.get().applyPattern(pattern);
            return formater.get().parse(date);
        } catch (ParseException ex) {
            throw new RuntimeException(ex);
        }
    }

    public static String toString(Date date, String pattern) {
        formater.get().applyPattern(pattern);
        return formater.get().format(date);
    }

    public static Date addDays(Date date, long days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_YEAR, (int) days);
        return cal.getTime();
    }
}
