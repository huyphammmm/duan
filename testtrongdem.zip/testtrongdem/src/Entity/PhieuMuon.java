/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;
import java.time.LocalDate;
/**
 *
 * @author ADMIN
 */
public class PhieuMuon {
    int ID;
    int IDNV;
    int IDTV;
    String tenNhanVien;
    String tenThanhVien;
    LocalDate ngayTaoPhieu;

    public PhieuMuon() {
    }

    public PhieuMuon(int ID, int IDNV, int IDTV, String tenNhanVien, String tenThanhVien, LocalDate ngayTaoPhieu) {
        this.ID = ID;
        this.IDNV = IDNV;
        this.IDTV = IDTV;
        this.tenNhanVien = tenNhanVien;
        this.tenThanhVien = tenThanhVien;
        this.ngayTaoPhieu = ngayTaoPhieu;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getIDNV() {
        return IDNV;
    }

    public void setIDNV(int IDNV) {
        this.IDNV = IDNV;
    }

    public int getIDTV() {
        return IDTV;
    }

    public void setIDTV(int IDTV) {
        this.IDTV = IDTV;
    }

    public String getTenNhanVien() {
        return tenNhanVien;
    }

    public void setTenNhanVien(String tenNhanVien) {
        this.tenNhanVien = tenNhanVien;
    }

    public String getTenThanhVien() {
        return tenThanhVien;
    }

    public void setTenThanhVien(String tenThanhVien) {
        this.tenThanhVien = tenThanhVien;
    }

    public LocalDate getNgayTaoPhieu() {
        return ngayTaoPhieu;
    }

    public void setNgayTaoPhieu(LocalDate ngayTaoPhieu) {
        this.ngayTaoPhieu = ngayTaoPhieu;
    }

    
}