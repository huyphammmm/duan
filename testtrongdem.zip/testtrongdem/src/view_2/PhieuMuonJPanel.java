/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package view_2;

import DAO.PhieuMuonDAO;
import DAO.ThanhVienDAO;
import Entity.PhieuMuon;
import Entity.ThanhVien;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JYearChooser;
import java.awt.Frame;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import utils.Auth;
import utils.MsgBox;


/**
 *
 * @author ADMIN
 */
public class PhieuMuonJPanel extends javax.swing.JPanel {
    ThanhVienDAO TVdao = new ThanhVienDAO();
    PhieuMuonDAO dao = new PhieuMuonDAO();
    int row = -1;
    
    int getIDThanhVienByName(String tenThanhVien) {   
        return 1;
    }
    JDayChooser dayChooser = new JDayChooser(); // Bộ chọn ngày
    JMonthChooser monthChooser = new JMonthChooser(); // Bộ chọn tháng
    JYearChooser yearChooser = new JYearChooser(); // Bộ chọn năm

    /**
     * Creates new form PhieuMuonJPanel
     */

    public PhieuMuonJPanel() {
        initComponents();
        init();

    }

    void init() {
        fillTable();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        Date date = new Date();
        System.out.println(formatter.format(date));
        this.fillComboBoxTS();
    }

    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    LocalDateTime now = LocalDateTime.now();

public void fillTable() {
    DefaultTableModel model = (DefaultTableModel) tblPhieuMuon.getModel();
    model.setRowCount(0);
    try {
        // Lấy ngày từ trường nhập liệu
        Date selectedDate = dateTimKiemNgay.getDate();

        // Sử dụng ngày hôm nay làm mặc định nếu chưa chọn ngày
        if (selectedDate == null) {
            selectedDate = new Date(); // Ngày hôm nay
        }

        LocalDate localSelectedDate = selectedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

        List<PhieuMuon> phieuMuonList;
        String keyword = txtTimKiem.getText().trim();

        if (!keyword.isEmpty()) {
            // Tìm kiếm theo từ khóa
            phieuMuonList = dao.selectByKeyword(keyword);
        } else {
            // Lấy các phiếu trong ngày đã chọn hoặc ngày mặc định
            phieuMuonList = dao.selectByDate(localSelectedDate);
        }

        for (PhieuMuon pm : phieuMuonList) {
            LocalDate ngayTao = pm.getNgayTaoPhieu();
            if (ngayTao != null && ngayTao.equals(localSelectedDate)) {
                Object[] row = {
                    pm.getID(),
                    pm.getTenNhanVien(),
                    pm.getTenThanhVien(),
                    ngayTao.toString() // Hiển thị chuỗi ngày
                };
                model.addRow(row);
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
        MsgBox.alert(this, "Đã xảy ra lỗi: " + e.getMessage());
    }
}

public void fillComBoBoxThanhVien() {
        DefaultComboBoxModel<String> model = (DefaultComboBoxModel<String>) cbbTenThanhVien.getModel();
        model.removeAllElements();
        List<ThanhVien> list = TVdao.selectAll();
        for (ThanhVien tv : list) {
            model.addElement(tv.getTen_thanh_vien());
        }
    }
    
  private void selectThanhVien(String ThanhVien) {
        for (int i = 0; i < cbbTenThanhVien.getItemCount(); i++) {
            String item = cbbTenThanhVien.getItemAt(i);
            if (item.equals(ThanhVien)) {
                cbbTenThanhVien.setSelectedIndex(i);
                return;
            }
        }
    }
    
    private void searchThanhVien() {
    String keyword = txtTimKiemThanhVien.getText().trim(); // Lấy giá trị từ ô tìm kiếm
    if (keyword.isEmpty()) {
        MsgBox.alert(this, "Vui lòng nhập ID thành viên để tìm kiếm");
        return;
    }

    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
    try {
        // Giả sử phương thức selectByID nhận ID và trả về một danh sách thành viên
        List<ThanhVien> thanhVienList = TVdao.selectByID(Integer.parseInt(keyword)); 
        for (ThanhVien tv : thanhVienList) {
            model.addElement(tv.getTen_thanh_vien());
        }
        cbbTenThanhVien.setModel(model);
    } catch (NumberFormatException e) {
        MsgBox.alert(this, "ID thành viên không hợp lệ!");
    } catch (Exception e) {
        e.printStackTrace();
        MsgBox.alert(this, "Tìm kiếm thất bại: " + e.getMessage());
    }
}

    
    private void fillComboBoxTS() {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        try {
            List<ThanhVien> sachList = TVdao.selectAll();
            for (ThanhVien tg : sachList) {
                model.addElement(tg.getTen_thanh_vien());
            }
            cbbTenThanhVien.setModel(model);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    PhieuMuon getForm() {
        PhieuMuon pm = new PhieuMuon();
        ThanhVien tv = TVdao.selectByName((String) cbbTenThanhVien.getSelectedItem());
        try {
            if (row >= 0) {
                pm.setID((int) tblPhieuMuon.getValueAt(row, 0));
                pm.setNgayTaoPhieu((LocalDate) tblPhieuMuon.getValueAt(row, 3));
            } else {
                pm.setID(0);
                pm.setNgayTaoPhieu(LocalDate.now());
            }
            pm.setIDTV(pm.getIDTV());
            pm.setTenThanhVien((String) cbbTenThanhVien.getSelectedItem());
            String tenNhanVien = Auth.user.getTenNV();
            if (tenNhanVien == null || tenNhanVien.isEmpty()) {
                MsgBox.alert(this, "Tên nhân viên không hợp lệ!");
                return null;
            }
            pm.setTenNhanVien(tenNhanVien);
            pm.setIDNV(Auth.user.getID()); // Ensure the IDNV is set correctly

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return pm;
    }
    
    public void setForm(PhieuMuon pm) {
        selectThanhVien(pm.getTenThanhVien());
        cbbTenThanhVien.setSelectedItem(pm.getTenThanhVien());
}


    void insert() {
    PhieuMuon pm = getForm();
    ThanhVien tv = TVdao.selectByName(pm.getTenThanhVien());
    if (tv == null) {
        MsgBox.alert(this, "Thành viên không tồn tại!");
        return;
    }
    pm.setIDTV(tv.getId());
    
    try {
        dao.insert(pm);
        fillTable();
        clearForm();
        MsgBox.alert(this, "Thêm mới thành công!");
    } catch (Exception e) {
        e.printStackTrace();
        MsgBox.alert(this, "Thêm mới thất bại!");
    }
}

    
    public void update() {
        PhieuMuon pm = getForm();
        try {
            dao.update(pm);
            fillTable();
            clearForm();
            MsgBox.alert(this, "Cập nhật thành công");
        } catch (Exception e) {
            MsgBox.alert(this, "Cập nhật thất bại: " + e.getMessage());
        }
    }

    void delete() {
        if (row < 0) {
            MsgBox.alert(this, "Chọn phiếu mượn cần xóa!");
            return;
        }

        int idPhieuMuon = (int) tblPhieuMuon.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa phiếu mượn này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                dao.delete(idPhieuMuon);
                fillTable();
                clearForm();
                MsgBox.alert(this, "Hủy thành công!");
            } catch (Exception e) {
                MsgBox.alert(this, "Xóa thất bại: " + e.getMessage());
            }
        }
    }

    public void clearForm() {
        PhieuMuon pm = new PhieuMuon();
        this.setForm(pm);
        this.row = -1;
    } 
    
    private void timKiem(){
        this.fillTable();
        this.clearForm();
        this.row = -1;

    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblPhieuMuon = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        btnTaoPhieuMuon = new javax.swing.JButton();
        btnHuyPhieu = new javax.swing.JButton();
        txtTimKiemThanhVien = new javax.swing.JTextField();
        btnTimKiemThanhVien = new javax.swing.JButton();
        cbbTenThanhVien = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtTimKiem = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        dateTimKiemNgay = new com.toedter.calendar.JDateChooser();

        jButton1.setText("jButton1");

        tblPhieuMuon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID phiếu mượn", "Tên nhân viên", "Tên thành viên", "Ngày tạo phiếu"
            }
        ));
        tblPhieuMuon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblPhieuMuonMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblPhieuMuon);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel9.setText("Tên TV");

        btnTaoPhieuMuon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Accept.png"))); // NOI18N
        btnTaoPhieuMuon.setText("Tạo phiếu mượn");
        btnTaoPhieuMuon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTaoPhieuMuon.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTaoPhieuMuon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTaoPhieuMuonActionPerformed(evt);
            }
        });

        btnHuyPhieu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Delete.png"))); // NOI18N
        btnHuyPhieu.setText("Hủy phiếu");
        btnHuyPhieu.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnHuyPhieu.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnHuyPhieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHuyPhieuActionPerformed(evt);
            }
        });

        txtTimKiemThanhVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemThanhVienActionPerformed(evt);
            }
        });

        btnTimKiemThanhVien.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Search.png"))); // NOI18N
        btnTimKiemThanhVien.setText("Tìm Kiếm Thành Viên");
        btnTimKiemThanhVien.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTimKiemThanhVien.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTimKiemThanhVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemThanhVienActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTimKiemThanhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(94, 94, 94)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnTaoPhieuMuon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 215, Short.MAX_VALUE)
                        .addComponent(btnHuyPhieu, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtTimKiemThanhVien)
                    .addComponent(cbbTenThanhVien, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnTimKiemThanhVien)
                            .addComponent(txtTimKiemThanhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbbTenThanhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnTaoPhieuMuon, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnHuyPhieu, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
        );

        jLabel1.setText("Phiếu mượn");

        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        txtTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTimKiemActionPerformed(evt);
            }
        });

        btnTimKiem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Search.png"))); // NOI18N
        btnTimKiem.setText("Tìm Kiếm Phiếu Mượn");
        btnTimKiem.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnTimKiem.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        jLabel11.setText("Nhập ID");

        jLabel12.setText("Nhập Ngày");

        dateTimKiemNgay.setDateFormatString("yyyy-dd-MM");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel11)
                        .addGap(34, 34, 34))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnTimKiem)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(txtTimKiem)
                    .addComponent(dateTimKiemNgay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dateTimKiemNgay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel12)
                        .addGap(0, 18, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(btnTimKiem))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 468, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 536, Short.MAX_VALUE)
                        .addGap(90, 90, 90))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void tblPhieuMuonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPhieuMuonMouseClicked
        // TODO add your handling code here:
        row = tblPhieuMuon.getSelectedRow();
        PhieuMuon pm = dao.selectById((Integer) tblPhieuMuon.getValueAt(row, 0));
        setForm(pm);
        int idPM = (Integer) tblPhieuMuon.getValueAt(row, 0);
        String tenTV = (String) tblPhieuMuon.getValueAt(row, 1);
        String tenNV = (String) tblPhieuMuon.getValueAt(row, 2);
        Frame parentFrame = null;
        CHITIETPHIEUMUON ct = new CHITIETPHIEUMUON(parentFrame, true, idPM, tenTV, tenNV);
        ct.setVisible(true);
    }//GEN-LAST:event_tblPhieuMuonMouseClicked

    private void btnTaoPhieuMuonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTaoPhieuMuonActionPerformed
        // TODO add your handling code here:
        this.insert();

    }//GEN-LAST:event_btnTaoPhieuMuonActionPerformed

    private void btnHuyPhieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHuyPhieuActionPerformed
        // TODO add your handling code here:
        this.delete();
    }//GEN-LAST:event_btnHuyPhieuActionPerformed

    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemActionPerformed
this.timKiem();        // TODO add your handling code here:
    }//GEN-LAST:event_btnTimKiemActionPerformed

    private void btnTimKiemThanhVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemThanhVienActionPerformed
this.searchThanhVien();// TODO add your handling code here:
    }//GEN-LAST:event_btnTimKiemThanhVienActionPerformed

    private void txtTimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemActionPerformed

    private void txtTimKiemThanhVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTimKiemThanhVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTimKiemThanhVienActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnHuyPhieu;
    private javax.swing.JButton btnTaoPhieuMuon;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnTimKiemThanhVien;
    private javax.swing.JComboBox<String> cbbTenThanhVien;
    private com.toedter.calendar.JDateChooser dateTimKiemNgay;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblPhieuMuon;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JTextField txtTimKiemThanhVien;
    // End of variables declaration//GEN-END:variables
}
