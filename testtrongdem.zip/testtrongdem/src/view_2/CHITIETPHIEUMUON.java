/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package view_2;

import java.util.*;
import Entity.ChiTietPhieuMuon;
import DAO.ChiTietPhieuMuonDAO;
import DAO.SachDAO;
import Entity.Sach;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import utils.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import javax.swing.JFrame;

/**
 *
 * @author luudi
 */
public class CHITIETPHIEUMUON extends javax.swing.JDialog {

    ChiTietPhieuMuonDAO dao = new ChiTietPhieuMuonDAO();
    int row = -1;
    SachDAO sd = new SachDAO();
    int getIDPhieuMuonByID(String ID){
        return 1;
    }
    int getIDSach(String ID_sach){
        return 1;
    }
    public int idPM;
    public String tenTV;
    public String tenNV;
    
    public CHITIETPHIEUMUON(java.awt.Frame parent, boolean modal, int idPM, String tenTV, String tenNV) {
        super(parent, modal);
        initComponents();
        setIdPM(idPM);
        setTenTV(tenTV);
        setTenNV(tenNV);
        init();
    }

    public String getTenTV() {
        return tenTV;
    }

    public void setTenTV(String tenTV) {
        this.tenTV = tenTV;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) {
        this.tenNV = tenNV;
    }

    public void setIdPM(int idPM) {
        this.idPM = idPM;
    }

    public int getIdPM() {
        return idPM;
    }

    void init() {
        setTitle("Bảng Chi Tieets");
        fillTable();
        fillComboBoxTS();
        jlbIdphieumuon.setText(this.getIdPM() + "");
        lblTenNV.setText(this.getTenNV() + "");
        lblTenTV.setText(this.getTenTV() + "");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();
        System.out.println(formatter.format(date));
    }

    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    LocalDateTime now = LocalDateTime.now();

    private void searchSach() {
        String keyword = txtTimKiemSach.getText();
        if (keyword.isEmpty()) {
            MsgBox.alert(this, "Vui lòng nhập tên sách để tìm kiếm");
            return;
        }

        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        try {
            List<Sach> sachList = sd.selectByTenSach(keyword); 
            for (Sach tg : sachList) {
                model.addElement(tg.getTenSach());
            }
            cboTenSach.setModel(model);
        } catch (Exception e) {
            e.printStackTrace();
            MsgBox.alert(this, "Tìm kiếm thất bại: " + e.getMessage());
        }
    }
    
    
    public void fillTable() {
        DefaultTableModel model = (DefaultTableModel) tblThongTin.getModel();
        model.setRowCount(0);
        try {
            List<ChiTietPhieuMuon> List = dao.selectByPhieuMuonId(idPM);
            for (ChiTietPhieuMuon ct : List) {
                Object[] row = {ct.getID(), ct.getIdPhieu(),
                    ct.getTenSach(), ct.getSoLuong(),
                    ct.getNgayMuon() != null ? ct.getNgayMuon().toString() : "", 
                    ct.getNgayTra(), ct.getNgay_tra_thuc_te(), ct.isTrangThai() ? "Đã Trả" : "Đang Mượn"};
                model.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void fillComboBoxTS() {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        try {
            List<Sach> sachList = sd.selectAll();
            for (Sach tg : sachList) {
                model.addElement(tg.getTenSach());
            }
            cboTenSach.setModel(model);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void selectSach(String Sach) {
        for (int i = 0; i < cboTenSach.getItemCount(); i++) {
            String item = cboTenSach.getItemAt(i);
            if (item.equals(Sach)) {
                cboTenSach.setSelectedIndex(i);
                return;
            }
        }
    }
  
    private ChiTietPhieuMuon getForm() {
    ChiTietPhieuMuon ctpm = new ChiTietPhieuMuon();
    String selectedSachName = (String) cboTenSach.getSelectedItem();
    Sach s = sd.selectByName(selectedSachName);
    if (s == null) {
        MsgBox.alert(this, "Không tìm thấy sách: " + selectedSachName);
        return null; 
    }
    ctpm.setID(row < 0 ? 0 : (int) tblThongTin.getValueAt(row, 0));
    ctpm.setIdPhieu(idPM);
    ctpm.setIdSach(s.getID());
    ctpm.setTenSach(selectedSachName);
    ctpm.setSoLuong(Integer.parseInt(txtSoLuong.getText()));
    LocalDate ngayMuon = LocalDate.now();
    ctpm.setNgayMuon(ngayMuon);
    LocalDate ngayTra = ngayMuon.plusDays(7);
    ctpm.setNgayTra(ngayTra.toString());
    ctpm.setTrangThai(jrTra.isSelected());
    return ctpm;
}
    
    public void setForm(ChiTietPhieuMuon ct) {
        selectSach(ct.getTenSach());
        txtSoLuong.setText(String.valueOf(ct.getSoLuong()));
        jrTra.setSelected(ct.isTrangThai());
        jrChua.setSelected(!ct.isTrangThai());
        //((JTextField) dateNgayTraThucTe.getDateEditor().getUiComponent()).setText(ct.getNgayTra());
        cboTenSach.setSelectedItem(ct.getTenSach());

    }

    public void insert() {
        ChiTietPhieuMuon ct = getForm();
        try {
            dao.insert(ct);
            fillTable();
            clearForm();
            //MsgBox.alert(this, "Thêm mới thành công");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update() {
    ChiTietPhieuMuon ct = getForm();
    if (ct == null) {
        return; 
    }
    try {
        dao.update(ct);
        fillTable();
        clearForm();
        MsgBox.alert(this, "Cập nhật thành công");
    } catch (Exception e) {
        MsgBox.alert(this, "Cập nhật thất bại: " + e.getMessage());
    }
}

    void delete() {
        if (row < 0) {
            MsgBox.alert(this, "Chọn tác giả cần xóa!");
            return;
        }

        int idTacGia = (int) tblThongTin.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa tác giả này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                dao.delete(idTacGia);
                fillTable();
                clearForm();
                MsgBox.alert(this, "Xóa thành công!");
            } catch (Exception e) {
                MsgBox.alert(this, "Xóa thất bại: " + e.getMessage());
            }
        }
    }

    public void clearForm() {
        ChiTietPhieuMuon tg = new ChiTietPhieuMuon();
        this.setForm(tg);
        this.row = -1; // Reset the row index
    }

    private void giaHanMuonSach() {
    if (row < 0) {
        MsgBox.alert(this, "Chọn sách cần gia hạn!");
        return;
    }
    int chiTietPhieuMuonId = (int) tblThongTin.getValueAt(row, 0);
    String inputDays = JOptionPane.showInputDialog(this, "Nhập số ngày cần gia hạn (tối đa 5 ngày):", "Gia hạn mượn sách", JOptionPane.QUESTION_MESSAGE);
    
    if (inputDays != null && !inputDays.trim().isEmpty()) {
        try {
            int extraDays = Integer.parseInt(inputDays.trim());
            if (extraDays > 5) {
                MsgBox.alert(this, "Số ngày gia hạn không được vượt quá 5 ngày.");
            } else {
                dao.extendLoan(chiTietPhieuMuonId, extraDays);
                fillTable(); 
            }
        } catch (NumberFormatException e) {
            MsgBox.alert(this, "Số ngày gia hạn không hợp lệ");
        }
    }
}
    
    private void timKiem(){
        this.fillTable();
        this.clearForm();
        this.row = -1;

    }
 

    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        btnSuaChiTiet = new javax.swing.JButton();
        btnXoaChiTiet = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        cboTenSach = new javax.swing.JComboBox<>();
        btnThemChiTiet = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jrTra = new javax.swing.JRadioButton();
        jrChua = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jlbIdphieumuon = new javax.swing.JLabel();
        lblTenTV = new javax.swing.JLabel();
        lblTenNV = new javax.swing.JLabel();
        lblTenTV1 = new javax.swing.JLabel();
        jlbIdphieumuon1 = new javax.swing.JLabel();
        lblTenNV1 = new javax.swing.JLabel();
        btnTimKiemSach = new javax.swing.JButton();
        txtTimKiemSach = new javax.swing.JTextField();
        btnLichSu = new javax.swing.JButton();
        btnGiaHan = new javax.swing.JButton();
        gg = new javax.swing.JScrollPane();
        tblThongTin = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        btnSuaChiTiet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnSuaChiTiet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Notes.png"))); // NOI18N
        btnSuaChiTiet.setText("Sửa Chi Tiết");
        btnSuaChiTiet.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnSuaChiTiet.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnSuaChiTiet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaChiTietActionPerformed(evt);
            }
        });

        btnXoaChiTiet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnXoaChiTiet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Delete.png"))); // NOI18N
        btnXoaChiTiet.setText("Xóa Chi Tiết");
        btnXoaChiTiet.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnXoaChiTiet.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnXoaChiTiet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaChiTietActionPerformed(evt);
            }
        });

        btnLamMoi.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLamMoi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Refresh.png"))); // NOI18N
        btnLamMoi.setText("Làm Mới");
        btnLamMoi.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnLamMoi.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        cboTenSach.setBackground(new java.awt.Color(242, 242, 242));

        btnThemChiTiet.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnThemChiTiet.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Accept.png"))); // NOI18N
        btnThemChiTiet.setText("Thêm Chi Tiết");
        btnThemChiTiet.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnThemChiTiet.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnThemChiTiet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemChiTietActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Tên Sách");

        txtSoLuong.setBackground(new java.awt.Color(242, 242, 242));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Số Lượng");

        buttonGroup1.add(jrTra);
        jrTra.setText("Đã Trả");

        buttonGroup1.add(jrChua);
        jrChua.setText("Đang Mượn");

        jLabel4.setText("Trạng Thái");

        jlbIdphieumuon.setText("ID phiếu");

        lblTenTV.setText("TênThanhVien");

        lblTenNV.setText("Tên Nhân Viên");

        lblTenTV1.setText("Tên Thành Viên");

        jlbIdphieumuon1.setText("ID phiếu : ");

        lblTenNV1.setText("Tên Nhân Viên : ");

        btnTimKiemSach.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Search.png"))); // NOI18N
        btnTimKiemSach.setText("Tìm Kiếm Sách");
        btnTimKiemSach.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);
        btnTimKiemSach.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemSachActionPerformed(evt);
            }
        });

        txtTimKiemSach.setBackground(new java.awt.Color(242, 242, 242));

        btnLichSu.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnLichSu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/List.png"))); // NOI18N
        btnLichSu.setText("Lịch sử mượn trả");
        btnLichSu.setHideActionText(true);
        btnLichSu.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnLichSu.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnLichSu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLichSuActionPerformed(evt);
            }
        });

        btnGiaHan.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnGiaHan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Book.png"))); // NOI18N
        btnGiaHan.setText("Gia hạn mượn sách");
        btnGiaHan.setHideActionText(true);
        btnGiaHan.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGiaHan.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGiaHan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGiaHanActionPerformed(evt);
            }
        });

        tblThongTin.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID Chi tiết Phiếu Mượn", "ID Phiếu Mượn", "Tên Sach", "Số Lượng", "Ngày Mượn", "Ngày Trả", "Ngày Trả Thực Tế", "Tình Trạng"
            }
        ));
        tblThongTin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblThongTinMouseClicked(evt);
            }
        });
        gg.setViewportView(tblThongTin);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jlbIdphieumuon1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jlbIdphieumuon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnTimKiemSach))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTenTV1)
                            .addComponent(lblTenNV1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(lblTenTV)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel4))
                                        .addGap(18, 18, 18))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(116, 116, 116)
                                        .addComponent(btnSuaChiTiet, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jrTra)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jrChua)))
                                        .addGap(187, 187, 187)
                                        .addComponent(jLabel1))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(12, 12, 12)
                                        .addComponent(btnXoaChiTiet, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnLamMoi, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnGiaHan))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblTenNV)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(btnThemChiTiet, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(686, 686, 686)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtTimKiemSach)
                        .addComponent(cboTenSach, 0, 196, Short.MAX_VALUE))
                    .addComponent(btnLichSu))
                .addGap(89, 89, 89))
            .addComponent(gg)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jlbIdphieumuon1)
                            .addComponent(jlbIdphieumuon)))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnTimKiemSach, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                            .addComponent(txtTimKiemSach, javax.swing.GroupLayout.Alignment.LEADING))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addComponent(lblTenTV)
                            .addComponent(lblTenNV1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblTenNV)
                            .addComponent(lblTenTV1)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cboTenSach, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jrTra)
                    .addComponent(jrChua)
                    .addComponent(jLabel4))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnLamMoi)
                    .addComponent(btnXoaChiTiet)
                    .addComponent(btnSuaChiTiet, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnThemChiTiet)
                    .addComponent(btnLichSu)
                    .addComponent(btnGiaHan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(gg, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSuaChiTietActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaChiTietActionPerformed
        this.update();   // TODO add your handling code here:
    }//GEN-LAST:event_btnSuaChiTietActionPerformed

    private void btnXoaChiTietActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXoaChiTietActionPerformed
        this.delete(); // TODO add your handling code here:
    }//GEN-LAST:event_btnXoaChiTietActionPerformed

    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLamMoiActionPerformed
        this.clearForm(); // TODO add your handling code here:
    }//GEN-LAST:event_btnLamMoiActionPerformed

    private void btnThemChiTietActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemChiTietActionPerformed
        this.insert();        // TODO add your handling code here:
    }//GEN-LAST:event_btnThemChiTietActionPerformed

    private void btnTimKiemSachActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTimKiemSachActionPerformed
this.searchSach();        // TODO add your handling code here:
    }//GEN-LAST:event_btnTimKiemSachActionPerformed

    private void btnLichSuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLichSuActionPerformed
        // TODO add your handling code here:
          LichSu lichSuD = new LichSu(null, true);
          lichSuD.setVisible(true);
    }//GEN-LAST:event_btnLichSuActionPerformed

    private void btnGiaHanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGiaHanActionPerformed
        // TODO add your handling code here:
               this.giaHanMuonSach();
    }//GEN-LAST:event_btnGiaHanActionPerformed

    private void tblThongTinMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblThongTinMouseClicked
        this.row = tblThongTin.getSelectedRow();
        if (this.row != -1) {
            int id = (int) tblThongTin.getValueAt(this.row, 0);
            ChiTietPhieuMuon ct = dao.selectById(id);
            this.setForm(ct);
        }       // TODO add your handling code here:
    }//GEN-LAST:event_tblThongTinMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CHITIETPHIEUMUON.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CHITIETPHIEUMUON.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CHITIETPHIEUMUON.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CHITIETPHIEUMUON.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CHITIETPHIEUMUON dialog = new CHITIETPHIEUMUON(new javax.swing.JFrame(), true, 1, "Ten Thanh Vien", "Ten Nhan Vien");
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                        LocalDateTime now = LocalDateTime.now();
                        System.out.println(dtf.format(now));
                    }

                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGiaHan;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnLichSu;
    private javax.swing.JButton btnSuaChiTiet;
    private javax.swing.JButton btnThemChiTiet;
    private javax.swing.JButton btnTimKiemSach;
    private javax.swing.JButton btnXoaChiTiet;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboTenSach;
    private javax.swing.JScrollPane gg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jlbIdphieumuon;
    private javax.swing.JLabel jlbIdphieumuon1;
    private javax.swing.JRadioButton jrChua;
    private javax.swing.JRadioButton jrTra;
    private javax.swing.JLabel lblTenNV;
    private javax.swing.JLabel lblTenNV1;
    private javax.swing.JLabel lblTenTV;
    private javax.swing.JLabel lblTenTV1;
    private javax.swing.JTable tblThongTin;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTimKiemSach;
    // End of variables declaration//GEN-END:variables

}
